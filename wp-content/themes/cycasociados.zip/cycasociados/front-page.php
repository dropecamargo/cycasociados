<?php

if ( 'posts' == get_option( 'show_on_front' ) ) {

		get_header();

		parallax_one_get_template_part( apply_filters("parallax_one_plus_header_layout","/sections/parallax_one_header_section"));
	?>
		</div>
		<!-- /END COLOR OVER IMAGE -->
	</header>
	<!-- /END HOME / HEADER  -->

	<div itemprop id="content" class="content-warp" role="main">

	<?php

		$sections_array = apply_filters("parallax_one_plus_sections_filter",array('sections/parallax_one_our_services_section', 'sections/parallax_one_ribbon_section', 'sections/parallax_one_our_story_section','sections/parallax_one_contact_info_section','sections/parallax_one_map_section'));

		if(!empty($sections_array)){
			foreach($sections_array as $section){
				parallax_one_get_template_part($section);
			}
		}
	?>

	</div><!-- .content-wrap -->

	<?php

	get_footer();
} else {

	include( get_page_template() );
}
?>
